package com.example.projectd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listview;
    FloatingActionButton fab;
    EditText task;
    MaterialCheckBox allChecked;
    String[] ListElements = new String[] {
        "Task"
    };
    final List< String > ListElementsArrayList = new ArrayList < String >(Arrays.asList(ListElements));


    public boolean areAllItemsChecked(){
        int allItemsChecked = 1;
        for(int i = 0; i < ListElementsArrayList.size(); i++){
            if(!listview.isItemChecked(i)) allItemsChecked = 0;
        }
        if(allItemsChecked == 1) {
            allChecked.setChecked(true);
            Toast toast = Toast.makeText(MainActivity.this, "You did it!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.BOTTOM, 0, 95);
            toast.show();
            return true;
        }
        else {
            allChecked.setChecked(false);
        }

        return false;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatabaseH db = new DatabaseH(this);
        db.getWritableDatabase();

        allChecked = findViewById(R.id.allChecked);
        listview = findViewById(R.id.listOfItems);
        fab = findViewById(R.id.fabAdd);
        task = findViewById(R.id.editText);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        final ArrayAdapter < String > adapter = new ArrayAdapter < String >(MainActivity.this, R.layout.checked_extended , ListElementsArrayList);
        listview.setAdapter(adapter);
        listview.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final MediaPlayer mpClick = MediaPlayer.create(MainActivity.this, R.raw.trapper);
                final MediaPlayer mpAllDone = MediaPlayer.create(MainActivity.this, R.raw.enspe);
                if(!areAllItemsChecked() && listview.isItemChecked(position))
                    mpClick.start();
                else if(areAllItemsChecked() && listview.isItemChecked(position))
                    mpAllDone.start();
            }
        });

        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                for(int i = position; i < ListElementsArrayList.size() - 1; i++){
                    if(listview.isItemChecked(i+1)) listview.setItemChecked(i, true);
                    else listview.setItemChecked(i, false);
                }
                listview.setItemChecked(ListElementsArrayList.size(), false);
                if(ListElementsArrayList.size() == 1) listview.setItemChecked(position, false);
                ListElementsArrayList.remove(position);
                adapter.notifyDataSetChanged();
                areAllItemsChecked();
                //Snackbar.make(view, "Task deleted", Snackbar.LENGTH_SHORT).setDuration(1500).setTextColor(Color.WHITE).setBackgroundTint(Color.DKGRAY).setAction("Action", null).show();
                Toast toast = Toast.makeText(MainActivity.this, "Task deleted", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.BOTTOM, 0, 95);
                toast.show();
                return true;
            }
        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,0);
                if(task.hasFocus())
                    if(task.getText().toString().isEmpty()){
                        //Snackbar.make(view, "Task cannot be empty", Snackbar.LENGTH_SHORT).setDuration(1500).setTextColor(Color.WHITE).setBackgroundTint(Color.DKGRAY).setAction("Action", null).show();
                        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                        Toast toast = Toast.makeText(MainActivity.this, "Task cannot be empty", Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.BOTTOM, 0, 95);
                        toast.show();
                        task.clearFocus();
                    }
                    else{
                        adapter.add(task.getText().toString());
                        task.setText("");
                        //Snackbar.make(view, "Task Added", Snackbar.LENGTH_SHORT).setDuration(1500).setTextColor(Color.WHITE).setBackgroundTint(Color.DKGRAY).setAction("Action", null).show();
                        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                        Toast toast = Toast.makeText(MainActivity.this, "Task added", Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.BOTTOM, 0, 95);
                        toast.show();
                        areAllItemsChecked();
                        task.clearFocus();
                    }
                else task.requestFocus();
            }
        });

        task.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View view, int keyCode, KeyEvent event) {

                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    // Perform action on key press
                    if(task.getText().toString().isEmpty()){
                        //Snackbar.make(view, "Task cannot be empty", Snackbar.LENGTH_SHORT).setDuration(1500).setTextColor(Color.WHITE).setBackgroundTint(Color.DKGRAY).setAction("Action", null).show();
                        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                        Toast toast = Toast.makeText(MainActivity.this, "Task cannot be empty", Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.BOTTOM, 0, 95);
                        toast.show();
                    }
                    else{
                        adapter.add(task.getText().toString());
                        db.addNote(new Note(ListElementsArrayList.size(), task.getText().toString(), 0));
                        task.setText("");
                        //Snackbar.make(view, "Task Added", Snackbar.LENGTH_SHORT).setDuration(1500).setTextColor(Color.WHITE).setBackgroundTint(Color.DKGRAY).setAction("Action", null).show();
                        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                        Toast toast = Toast.makeText(MainActivity.this, "Task added", Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.BOTTOM, 0, 95);
                        toast.show();
                    }
                    areAllItemsChecked();
                    return true;
                }
                return false;
            }
        });




    }
}