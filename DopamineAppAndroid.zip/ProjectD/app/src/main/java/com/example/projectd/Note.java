package com.example.projectd;

public class Note {
    int id;
    String text;
    boolean checkM;

    public Note(){}

    public Note(int id){
        this.id = id;
    }

    public Note(int id, String text, int checkInt){
        this.id = id;
        this.text = text;
        if(checkInt == 1)
            this.checkM = true;
        else this.checkM = false;
    }

    public int getId(){
        return this.id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getText(){
        return this.text;
    }

    public void setText(String text){
        this.text = text;
    }

    public int getCheckM(){
        if(this.checkM)
            return 1;
        else return 0;
    }

    public void setCheckM(int checkM){
        if(checkM == 1)
            this.checkM = true;
        else this.checkM = false;
    }
}
